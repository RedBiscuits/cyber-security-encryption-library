﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecurityLibrary.DiffieHellman
{


    public class DiffieHellman
    {

      public  int power(int f, int s, int sf)
        {
            throw new NotImplementedException();
        }

       public List<int> GetKeys(int q, int alpha, int xa, int xb)
        {

            throw new NotImplementedException();
        }
    }
}